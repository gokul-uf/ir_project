package ch.ethz.dal.tinyir.lectures

import ch.ethz.dal.tinyir.processing.Tokenizer
import scala.util.Random

object Test {

}