
Reuters Research and Standards Group - Corpus Code definitions
--------------------------------------------------------------


Code Definitions        File Name               File Size
----------------        ------------------      ---------

Region codes            region_codes.txt        8k

Topic codes             topic_codes.txt         3k

Industry codes          industry_codes.txt      25k


The code files start with two comment lines (indicated by a semi-colon).

The codes are one per line and have the code and description separated
by a TAB character.


